
public class Variable {

	public static void main(String[] args) {
		
		int a = 1; // Number -> integer  ... -2, -1 , 0, 1, 2 ...
		System.out.println(a);
		
		double b = 1.1; // real number -> double ... -2.0, -1.0, 0, 1.0, 2.0 ...
		System.out.println(b);
		
		String c = "Hello World";
		System.out.println(c);
	}

}
