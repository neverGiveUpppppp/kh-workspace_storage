package prac.prac.practice.board.model.service;


public interface BoardService {

}
