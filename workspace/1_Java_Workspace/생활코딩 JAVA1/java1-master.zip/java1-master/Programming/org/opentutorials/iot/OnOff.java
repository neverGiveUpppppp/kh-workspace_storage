package org.opentutorials.iot;

public interface OnOff {
	public boolean on();
	public boolean off();
}
