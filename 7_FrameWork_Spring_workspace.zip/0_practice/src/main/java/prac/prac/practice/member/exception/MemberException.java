package prac.prac.practice.member.exception;

public class MemberException extends RuntimeException{

	public MemberException() {}
	public MemberException(String msg) {
		super(msg);
	}
}

