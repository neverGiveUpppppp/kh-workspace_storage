package prac.prac.practice.board.exception;

public class BoardException extends RuntimeException {

	public BoardException() {}
	public BoardException(String msg) {
		super();
	}
}
