package prac.prac.practice.member.model.dao;

import org.springframework.stereotype.Repository;

@Repository("memberDAO")
public class MemberDAO {

	
	
}
