package prac.prac.practice.member.model.service;

public interface MemberService {
	
	

}
