package prac.prac.practice.board.model.dao;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;

@Repository("boardDAO")
public class BoardDAO {

	
	
}
